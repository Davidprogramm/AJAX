package com.example.trabajoSpringWeb.controlador;

import com.example.trabajoSpringWeb.entidad.ciclistas;
import com.example.trabajoSpringWeb.servicio.ciclistasServicio;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ciclista")
@CrossOrigin(origins = "*")
public class ciclistasControlador {

    private ciclistasServicio ciclistaServicio;

    public ciclistasControlador(ciclistasServicio ciclistaServicio) {
        this.ciclistaServicio = ciclistaServicio;
    }

    @GetMapping("/todos")
    public List<ciclistas> todosCiclistas() {
        return ciclistaServicio.todosCiclistas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ciclistas> ciclistaPorID(@PathVariable String id) {
        ciclistas ciclista = ciclistaServicio.ciclistaPorId(id);
        if (ciclista == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(ciclista, HttpStatus.OK);
        }
    }

    @PostMapping("/nuevo")
    public ResponseEntity<ciclistas> agregarCiclista(@RequestBody ciclistas nuevoCiclista) {
        if (ciclistaServicio.ciclistaPorId(nuevoCiclista.getId()) == null) {
            ciclistaServicio.agregarCiclista(nuevoCiclista);
            return new ResponseEntity<>(nuevoCiclista, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/actualizar")
    public ResponseEntity<ciclistas> actualizarCiclista(@RequestBody ciclistas ciclistaActualizacion) {
        ciclistaServicio.actualizarCiclista(ciclistaActualizacion);
        return new ResponseEntity<>(ciclistaActualizacion, HttpStatus.ACCEPTED);
    }

    @DeleteMapping("/borrar/{id}")
    public ResponseEntity<?> borrarCiclista(@PathVariable String id) {
        ciclistaServicio.borrarCiclista(id);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}