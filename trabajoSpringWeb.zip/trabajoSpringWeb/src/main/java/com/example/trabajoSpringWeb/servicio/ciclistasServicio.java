package com.example.trabajoSpringWeb.servicio;

import com.example.trabajoSpringWeb.entidad.ciclistas;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public class ciclistasServicio {
    private ArrayList<ciclistas> listaCiclistas = new ArrayList<>();

    public ciclistasServicio() {
    }

    public ArrayList<ciclistas> todosCiclistas() {
        return listaCiclistas;
    }

    public ciclistas ciclistaPorId(String id) {
        for (ciclistas c : listaCiclistas) {
            if (c.getId().equals(id)) {
                return c;
            }
        }
        return null;
    }

    public void agregarCiclista(ciclistas ciclista) {
        listaCiclistas.add(ciclista);
    }

    public void borrarCiclista(String id) {
        ciclistas ciclistaBorrar = null;
        for (ciclistas c : listaCiclistas) {
            if (c.getId().equals(id)) {
                ciclistaBorrar = c;
                break;
            }
        }
        if (ciclistaBorrar != null) {
            listaCiclistas.remove(ciclistaBorrar);
        }
    }

    public void actualizarCiclista(ciclistas ciclistaActualizacion) {
        for (ciclistas c : listaCiclistas) {
            if (c.getId().equals(ciclistaActualizacion.getId())) {
                c.setId(ciclistaActualizacion.getId());
                c.setNombre(ciclistaActualizacion.getNombre());
                c.setApellido(ciclistaActualizacion.getApellido());
                c.setEdad(ciclistaActualizacion.getEdad());
                c.setEquipo(ciclistaActualizacion.getEquipo());
                break;
            }
        }
    }
}