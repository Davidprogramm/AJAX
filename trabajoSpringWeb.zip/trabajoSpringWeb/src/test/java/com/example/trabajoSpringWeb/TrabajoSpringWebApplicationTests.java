package com.example.trabajoSpringWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoSpringWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
